#Gabriel dos Santos Souza - 1459589

library(tidyverse)
cv <- read.delim("C:/Users/gabriel.souza/Desktop/ativ24/carros_venda_webmotors_270314.txt")

head(cv)

cvt <- cv
cvt$CORM <- toupper(cv$cor)

min(cvt$preco)
max(cvt$preco)

cvt$preco_norm <- (cvt$preco - min(cvt$preco)) / (max(cvt$preco) - min(cvt$preco))

summary(cvt$preco_norm)

cvt2 <- cv %>% mutate(cor_maius = toupper(cor))

dividir <- function(anomod, index) {
  anomod <- as.character(anomod)
  tmp <- strsplit(anomod, "/")[[1]]
  tmp <- as.numeric(tmp)
  return(tmp[index])
}

dividir("2011/2012", 1)
dividir("2011/2012", 2)

imprimirImpares <- function(limite = 10) {
  for (i in 1: limite) {
    if (i%% 2 !=0) {
      print(i)
    }
  }
}
imprimirImpares()
imprimirImpares(50)

cv3 <- cv %>%
  rowwise() %>%
  mutate(ano_fab = dividir(anomod, 1), ano_modelo = dividir(anomod, 2))

str(cv3)

cv3 %>% ggplot(aes(x = ano_fab, y = preco)) + geom_line()

cv3  %>% filter(carro == "amarok")  %>% ggplot(aes(x = ano_fab, y = preco)) + geom_line()

cv3  %>% filter(carro == "amarok")  %>% ggplot(aes(x = ano_fab, y = preco)) + geom_point()

cv3 %>% ggplot(aes(x = ano_fab, y = preco)) + geom_point()

cv3 %>% ggplot(aes(x = ano_fab, y = preco, color = carro)) + geom_point()

cv3 %>% 
  filter(carro %in% c("amarok", "hilux")) %>% 
  ggplot(aes(x = ano_fab, y = preco, color = carro)) + geom_point()

cv3  %>% filter(carro == "amarok")  %>% ggplot(aes(x = ano_fab, y = preco)) + geom_point() + geom_line()

cv3 %>% 
  filter(carro == "amarok") %>% 
  ggplot(aes(x = ano_fab, y = preco)) +
  geom_point() +
  geom_hline(yintercept=110000, color= "red")

cv3 %>%
  ggplot(aes(x = ano_fab, y = preco)) +
  geom_point() +
  stat_smooth()

cv3 %>% 
  filter(carro == "gol") %>% 
  ggplot(aes(x = ano_fab, y = preco)) +
  geom_point() +
  stat_smooth()

cv3 <- mutate(cv3, anos_uso = 2014 - ano_fab)

cv3 %>% 
  filter(carro == "uno") %>% 
  ggplot(aes(x = anos_uso, y = preco)) +
  geom_point() +
  stat_smooth() +
  scale_x_continuous(breaks = seq(0, 32, by = 1))

cv3 %>% 
  filter(carro == "gol") %>% 
  ggplot(aes(x = anos_uso, y = preco)) +
  geom_point() +
  stat_smooth() +
  scale_x_continuous(breaks = seq(0, 32, by = 1))

cv3 %>% 
  filter(carro %in% c("gol", "uno")) %>% 
  ggplot(aes(x = anos_uso, y = preco, fill = carro)) +
  geom_point() +
  stat_smooth() +
  scale_x_continuous(breaks = seq(0, 32, by = 1))
  


